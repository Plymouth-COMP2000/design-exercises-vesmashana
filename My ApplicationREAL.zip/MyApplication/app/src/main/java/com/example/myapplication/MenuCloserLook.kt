package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MenuCloserLook : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.menucloserlook)
        val back = findViewById<ImageButton>(R.id.imageButton7)
        back.setOnClickListener {
            val intent = Intent(this, Menu::class.java)
            startActivity(intent)

        }

    }
}