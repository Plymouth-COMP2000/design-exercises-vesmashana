package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import android.widget.ImageButton
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class StaffCentre : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.staff_centre)
        val staffReservations = findViewById<ImageView>(R.id.imageView16)
        staffReservations.setOnClickListener {
            val intent = Intent(this, StaffReservations::class.java)
            startActivity(intent)
        }
        val staffMenu = findViewById<ImageView>(R.id.imageView18)
        staffMenu.setOnClickListener {
            val intent2 = Intent(this, StaffMenu::class.java)
            startActivity(intent2)
        }

    }
}