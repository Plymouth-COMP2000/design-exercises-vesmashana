package com.example.myapplication.ui.theme

class StaffResAdapter {
}