package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.google.android.material.textfield.TextInputEditText
import androidx.core.widget.doAfterTextChanged
class Code : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.code)
        val login = findViewById<ImageButton>(R.id.imageButton4)
        login.setOnClickListener {
            val intent = Intent(this, Reservations::class.java)
            startActivity(intent)
        }
        val codeInput = findViewById<TextInputEditText>(R.id.textInputEditText)
        codeInput.doAfterTextChanged {
            if (it.toString() == "XXXX") {
                val intent2 = Intent(this, YourReservation::class.java)
                startActivity(intent2)
            }
        }
    }
}