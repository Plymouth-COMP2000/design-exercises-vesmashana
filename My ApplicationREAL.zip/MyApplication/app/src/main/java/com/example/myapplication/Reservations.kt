package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.CalendarView
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import android.graphics.Color

class Reservations : AppCompatActivity() {
    private var date: String = ""
    private var selected: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.reservations)
        val back = findViewById<ImageButton>(R.id.imageButton2)
        back.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        val code = findViewById<Button>(R.id.button3)
        code.setOnClickListener {
            val intent2 = Intent(this, Code::class.java)
            startActivity(intent2)
        }
        val confirmbooking = findViewById<Button>(R.id.button2)
        confirmbooking.setOnClickListener {
            val name = findViewById<TextInputEditText>(R.id.nameEditText).text.toString()
            if (name.isEmpty()) {
                val warning1 = findViewById<TextView>(R.id.textView70)
                warning1.text = "*This is a required field"
            }else if(date.isEmpty()){
                val warning2 = findViewById<TextView>(R.id.textView65)
                warning2.text = "*This is a required field"

            }else if(selected.isEmpty()){
                val warning3 = findViewById<TextView>(R.id.textView64)
                warning3.text = "*This is a required field"

            }
            else {
                val intent2 = Intent(this, ConfirmBooking::class.java)
                intent2.putExtra("name", name)
                intent2.putExtra("timeslot", selected)
                intent2.putExtra("date", date)
                startActivity(intent2)
            }
        }

        val calendarView = findViewById<CalendarView>(R.id.calendarView)
        calendarView.minDate = System.currentTimeMillis() - 1000
        calendarView.maxDate = System.currentTimeMillis() + 31536000000
        val timeslots = listOf("12:30", "13:00", "14:00", "15:30", "16:30", "17:00", "18:00")

        val views = listOf(
            findViewById<TextView>(R.id.textView11),
            findViewById<TextView>(R.id.textView12),
            findViewById<TextView>(R.id.textView13),
            findViewById<TextView>(R.id.textView16),
            findViewById<TextView>(R.id.textView66),
            findViewById<TextView>(R.id.textView67),
            findViewById<TextView>(R.id.textView68),
            findViewById<TextView>(R.id.textView69)
        )

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            date = (dayOfMonth.toString() + "-" + (month + 1) + "-" + year)
            for (i in timeslots.indices) {
                views[i].setBackgroundColor(Color.parseColor("#FFFFFF"))
            }
            for (i in timeslots.indices) {
                views[i].text = timeslots[i]

                views[i].setOnClickListener {
                    selected = timeslots[i]
                    for (i in timeslots.indices) {
                        views[i].setBackgroundColor(Color.parseColor("#FFFFFF"))
                    }
                    views[i].setBackgroundColor(Color.parseColor("#5DB2F6"))
                }
            }

        }




    }
}