package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.tabs.TabLayout;

class StaffReservations : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.staff_reservations)
        val back = findViewById<ImageButton>(R.id.imageButton13)
        back.setOnClickListener {
            val intent = Intent(this, StaffCentre::class.java)
            startActivity(intent)
        }
        val searchByName = findViewById<ImageButton>(R.id.imageButton14)
        searchByName.setOnClickListener {
            val intent1 = Intent(this, SearchByName::class.java)
            startActivity(intent1)
        }
        val staffLog = findViewById<ImageButton>(R.id.imageButton15)
        staffLog.setOnClickListener {
            val intent2 = Intent(this, ReservationsLog::class.java)
            startActivity(intent2)
        }
        val daysOfWeek = findViewById<TabLayout>(R.id.tab_layout)
        daysOfWeek.addTab(daysOfWeek.newTab().setText("Mo"))
        daysOfWeek.addTab(daysOfWeek.newTab().setText("Tue"))
        daysOfWeek.addTab(daysOfWeek.newTab().setText("We"))
        daysOfWeek.addTab(daysOfWeek.newTab().setText("Thu"))
        daysOfWeek.addTab(daysOfWeek.newTab().setText("Fri"))
        daysOfWeek.addTab(daysOfWeek.newTab().setText("Sat"))
        daysOfWeek.addTab(daysOfWeek.newTab().setText("Sun"))
        daysOfWeek.addTab(daysOfWeek.newTab().setText("Cal"))
    }
}