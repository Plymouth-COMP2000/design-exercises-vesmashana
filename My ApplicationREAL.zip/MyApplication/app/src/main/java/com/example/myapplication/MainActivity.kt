package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val res = findViewById<Button>(R.id.button)
        res.setOnClickListener {
            val intent = Intent(this, Reservations::class.java)
            startActivity(intent)
        }

        val menu = findViewById<Button>(R.id.button4)
        menu.setOnClickListener {
            val gotomenu = Intent(this, Menu::class.java)
            startActivity(gotomenu)
        }
        val login = findViewById<Button>(R.id.button5)
        login.setOnClickListener {
            val intent = Intent(this, stafflogin::class.java)
            startActivity(intent)
        }
    }
}
