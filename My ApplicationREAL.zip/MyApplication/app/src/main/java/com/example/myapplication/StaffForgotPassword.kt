package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.widget.Button

class StaffForgotPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.staff_login2)
        val back = findViewById<ImageButton>(R.id.imageButton9)
        back.setOnClickListener {
            val intent = Intent(this, stafflogin::class.java)
            startActivity(intent)

        }
        val sendcode = findViewById<Button>(R.id.button20)
        sendcode.setOnClickListener {

        }
    }
}