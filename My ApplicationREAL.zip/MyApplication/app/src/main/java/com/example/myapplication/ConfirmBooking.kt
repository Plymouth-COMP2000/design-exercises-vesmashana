package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.TextView
import android.widget.CheckBox
import com.google.android.material.textfield.TextInputEditText

class ConfirmBooking : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.confirmbooking)
        var windowSeat: Int? = null
        var barSeat: Int? = null
        var numberOfPeople: Int? = null
        val date = intent.getStringExtra("date")
        val timeslot = intent.getStringExtra("timeslot")
        val name = intent.getStringExtra("name")
        val displayDate = findViewById<TextView>(R.id.textView9)
        displayDate.text = date
        val displayTimeslot = findViewById<TextView>(R.id.textView8)
        displayTimeslot.text = timeslot



        val back = findViewById<ImageButton>(R.id.imageButton)
        back.setOnClickListener {
            val intent = Intent(this, Reservations::class.java)
            startActivity(intent)
        }
        val PlaceBooking = findViewById<Button>(R.id.button6)
        PlaceBooking.setOnClickListener {
            val checkboxWindow = findViewById<CheckBox>(R.id.checkBox)
            val checkboxBar = findViewById<CheckBox>(R.id.checkBox2)
            val peopleEntry = findViewById<TextInputEditText>(R.id.textInputEditText2)
            if (checkboxWindow.isChecked()) {
                windowSeat = 1
            } else {
                windowSeat = 0
            }
            if (checkboxBar.isChecked()) {
                barSeat = 1
            } else {
                barSeat = 0
            }
            numberOfPeople = peopleEntry.text.toString().toIntOrNull()

            val peopleCount = numberOfPeople

            if (peopleCount != null) {
                if (peopleCount < 15) {
                    val intent = Intent(this, Success::class.java)
                    startActivity(intent)
                } else {
                    val warning = findViewById<TextView>(R.id.textView71)
                    warning.text = "*We don't currently accept reservations of over 14 people"

                }
            } else {
                val warning = findViewById<TextView>(R.id.textView71)
                warning.text = "*This is a required field"
            }
        }
    }
}
