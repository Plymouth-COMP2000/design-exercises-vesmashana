package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.TextView

class stafflogin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.staff_login1)
        val back = findViewById<ImageButton>(R.id.imageButton8)
        back.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        val forgotpassword = findViewById<TextView>(R.id.textView35)
        forgotpassword.setOnClickListener {
            val intent1 = Intent(this, StaffForgotPassword::class.java)
            startActivity(intent1)
        }
        val login = findViewById<Button>(R.id.button19)
        login.setOnClickListener {
            val intent2 = Intent(this, StaffCentre::class.java)
            startActivity(intent2)
        }
    }
}