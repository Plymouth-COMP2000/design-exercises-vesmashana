package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class StaffMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.staff_menu)
        val back = findViewById<ImageButton>(R.id.imageButton17)
        back.setOnClickListener {
            val intent = Intent(this, StaffCentre::class.java)
            startActivity(intent)
        }
        val addItem = findViewById<ImageView>(R.id.imageView17)
        addItem.setOnClickListener {
            val intent1 = Intent(this, AddItem::class.java)
            startActivity(intent1)
        }
    }
}